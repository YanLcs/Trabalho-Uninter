package Main;

public class Real extends Moeda {
    
    public Real(double valor) {
        super(valor);
    }

    @Override
    public String info() {
        return "Real: R$" + valor;
    }

    @Override
    public double converter() {
        return valor;  
    }
}