package Main;

import java.util.ArrayList;

//Classe do cofrinho
public class Cofrinho {
	//Array que contém as moedas
    private ArrayList<Moeda> listaMoedas;

    public Cofrinho() {
        listaMoedas = new ArrayList<>();
    }

    //Adicionar uma moeda
    public void adicionar(Moeda moeda) {
        listaMoedas.add(moeda);
    }

    
    //Remover uma moeda
    public boolean remover(Moeda moeda) {
        return listaMoedas.remove(moeda);
    }
    
    //Remover por indíce, para poder remover um registro específico adicionado
    public Moeda removerPorIndice(int indice) {
        if (indice >= 0 && indice < listaMoedas.size()) {
            return listaMoedas.remove(indice);
        }
        return null;
    }

    //Listar todas as moedas
    public void listagemMoedas() {
        for (int i = 0; i < listaMoedas.size(); i++) {
            System.out.printf("Moeda número1 %02d: %s\n", i, listaMoedas.get(i).info());

        }
    }

    public boolean estaVazio() {
        return listaMoedas.isEmpty();
    }
    
    //Total convertido
    public double totalConvertido() {
        double total = 0;
        for (Moeda moeda : listaMoedas) {
            total += moeda.converter();
        }
        return total;
    }
}
