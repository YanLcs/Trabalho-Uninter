package Main;

public class Euro extends Moeda {
    
    // Taxa de conversão de euro para real
    private static final double TAXA_CONVERSAO = 6.0; // Valor aproximado da conversão de euro para real
    public Euro(double valor) {
        super(valor);
    }

    @Override
    public String info() {
        return "Euro: €" + valor;
    }

    @Override
    public double converter() {
        return valor * TAXA_CONVERSAO;
    }
}
