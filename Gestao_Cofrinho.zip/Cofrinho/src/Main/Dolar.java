package Main;

public class Dolar extends Moeda {
    
    // Taxa de conversao de dolar em real
    private static final double TAXA_CONVERSAO = 5.0; // Valor aproximado da conversão de dólar para real
    public Dolar(double valor) {
        super(valor);
    }

    @Override
    public String info() {
        return "Dólar: $" + valor;
    }

    @Override
    public double converter() {
        return valor * TAXA_CONVERSAO;
    }
}