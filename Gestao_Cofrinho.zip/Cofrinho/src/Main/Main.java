package Main;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Main {
	
	// Opções do menu do sistema de gestão do cofrinho
	private static final int ADICIONAR_MOEDA = 1;
	private static final int REMOVER_MOEDA = 2;
	private static final int LISTAR_MOEDAS = 3;
	private static final int CALCULAR_TOTAL = 4;
	private static final int SAIR = 0;
	
	// Opções do sub-menu Adição de Moedas
	private static final int REAL = 1;
	private static final int DOLAR = 2;
	private static final int EURO = 3;
	 
    public static void main(String[] args) {
 	   
    	//Utilizando o scanner para a leitura dos dados
        Scanner leitura_dados = new Scanner(System.in);
        
        //Iniciando a classe cofrinho
        Cofrinho cofrinho = new Cofrinho();
        int opcao = -1;

        /** Loop da aplicação do cofrinho **/
        
        while (opcao != 0) {
            try {
                System.out.println("\n Menu de opções do Sistema de gestão do cofrinho\n");
                System.out.println("1. Adicionar moeda");
                System.out.println("2. Remover moeda");
                System.out.println("3. Listagem de moedas");
                System.out.println("4. Calcular total convertido em reais");
                System.out.println("0. Sair");
                System.out.print("\n Escolha uma opção: ");
                
                opcao = leitura_dados.nextInt();
                leitura_dados.nextLine();  

                // Switch-case para selecionar a próxima ação com base no valor inserido pelo usuário
                switch (opcao) {
                    case ADICIONAR_MOEDA:
                    	// Método para adicionar moedas 
                        adicionarMoeda(leitura_dados, cofrinho);
                        break;
                    case REMOVER_MOEDA:
                        // Método para remocer moedas 
                    	removerMoeda(leitura_dados, cofrinho);
                        break;
                    case LISTAR_MOEDAS:
                        //Verifica se o cofrinho não está vazio
                        if (cofrinho.estaVazio()) {
                            System.out.println("Não existe moedas, o cofrinho está vazio!");
                        }
                        else
                        {
                        // Se o cofrinho não está vazio, lista as moedas
                            cofrinho.listagemMoedas();
                        }
                        break;
                    case CALCULAR_TOTAL:
                    	// Total convertido de moedas 
                        System.out.printf("Total convertido em Reais: R$%.2f\n", cofrinho.totalConvertido());
                        break;
                    case SAIR:
                        System.out.println("Programa encerrado! ");
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
            } catch (Exception e) {
                System.out.println("Erro ao processar entrada! => "+e.getMessage());
                leitura_dados.next(); // Descarta a entrada inválida
            }
        }

        leitura_dados.close();
    }

    	// Método para adicionar moedas
    private static void adicionarMoeda(Scanner scanner, Cofrinho cofrinho) {
        try {
            System.out.println("\nTipos de moeda: ");
            System.out.println("1. Real");
            System.out.println("2. Dólar");
            System.out.println("3. Euro");
            System.out.print("Digite a moeda: ");
            int tipoMoeda = scanner.nextInt();
            System.out.print("Digite o valor da moeda: ");
            double valor = scanner.nextDouble();
            scanner.nextLine();  

            switch (tipoMoeda) {
                case REAL:
                    cofrinho.adicionar(new Real(valor));
                    break;
                case DOLAR:
                    cofrinho.adicionar(new Dolar(valor));
                    break;
                case EURO:
                    cofrinho.adicionar(new Euro(valor));
                    break;
                default:
                    System.out.println("Tipo de moeda inválido!");
            }
        } catch (Exception e) {
        	   System.out.println("Erro ao processar entrada! => "+e.getMessage());
               scanner.next(); // Descarta a entrada inválida
        }
    }
    
    
    
    	//Método para remover moeda
    private static void removerMoeda(Scanner scanner, Cofrinho cofrinho) {

        //Verifica se o cofre não está vazio
        if (cofrinho.estaVazio()) {
            System.out.println("Não existe moedas, o cofrinho está vazio!");
            return;
        }
        else {
        	System.out.println("\nMoedas existentes :");
        }

        //Lista a moeda para o usuário escolher qual será deletada
        cofrinho.listagemMoedas();
        System.out.print("Digite o índice da moeda que deseja remover: ");
        int indice = scanner.nextInt();
        scanner.nextLine();  

        //Remove a moeda com base no seu índice
        Moeda moedaRemovida = cofrinho.removerPorIndice(indice);
        if (moedaRemovida != null) {
            System.out.println("Moeda removida: " + moedaRemovida.info());
        } else {
            System.out.println("Índice inválido!.");
        }
    }
}
